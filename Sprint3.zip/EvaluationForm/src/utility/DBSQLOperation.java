package utility;

import java.sql.*;

import model.ResultBean;
import model.ScheduleBean;
public class DBSQLOperation implements DBSQLCommand{

	public static boolean insertResult(ResultBean rb, Connection connection) {

		boolean isSuccessful = false;

		if (connection != null) {
			try {
				PreparedStatement pstmnt = 
					connection.prepareStatement(INSERT_RESULT);
				
				pstmnt.setInt(1, rb.getStudentID());
				pstmnt.setInt(2, rb.getProfID());
				pstmnt.setString(3, rb.getCourseCode());
				System.out.println(rb.getCourseCode());
				pstmnt.setString(4, rb.getTerm());
				pstmnt.setString(5, rb.getSchoolYear());
				pstmnt.setString(6, rb.getSection());
				pstmnt.setInt(7, rb.getQID());
				pstmnt.setInt(8, rb.getRate());
				
				
				pstmnt.executeUpdate();
				isSuccessful = true;
				System.out.println("Result Submitted");
			} catch (SQLException sqle) {
				System.err.println(sqle.getMessage());
			}
		}
		return isSuccessful;
	}
	
	public static ResultSet selectSchedule(ScheduleBean sb, Connection connection){
		
		ResultSet records = null;
		
		String DISPLAY_SCHEDULE = SELECT_SCHEDULE + sb.getStudentID();
		
		if (connection != null) {
			try {
				PreparedStatement pstmnt = 
					connection.prepareStatement(DISPLAY_SCHEDULE);
			
				ResultSet rs = pstmnt.executeQuery();
				
				
				while(rs.next()){
					
					sb.setSubject(rs.getString("courseName"));
					sb.setProfessor(rs.getString("professorName"));
					sb.setTime(rs.getString("courseTime"));
					
				}
				
				System.out.println(sb.getSubject());
			}catch(SQLException sqle){
				System.err.println(sqle.getMessage());
				
			}
		}  else {
			System.err.println("insertRecord(): connection is null.");
		}		
		
		System.out.println("Records");
		return records;
	
		
	}
}
